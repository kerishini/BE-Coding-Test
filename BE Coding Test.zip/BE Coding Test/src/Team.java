public class Team {
    String name;
    int score;

    public Team(){
        this.score= 0;
    }

    public int getScore() { return score; }

    public void setScore(int score) { this.score = score; }

    public String getName() {
        return name;
    }

    public void setName(String name) { this.name = name; }

}

